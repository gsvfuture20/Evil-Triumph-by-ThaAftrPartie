package com.ThaAftrPartie.EvilTriumph.events;



public class LootTableEvent {
	{
	//	@SubscribeEvent
	//	public  customLootTableDrop(LivingDropsEvent event)
	//	{
	//		Random rand = new Random();
		//	if(event.getEntityLiving() instanceof EntityLivingBase)
			//{
				//if(rand.nextInt(1) == 0)
				//{
					//event.getEntityLiving().entityDropItem(new ItemStack(ItemInit.OKONOTH_INGOT), 0.0f);
				//}
				
				//if(rand.nextInt(20) == 0)
				//{
					//event.getEntityLiving().entityDropItem(new ItemStack(BlockInit.OKONOTH_BLOCK), 0.0f);
				//}
			//}
			
			//if(event.getEntityLiving() instanceof EntitySilverfish)
			//{
				//if(rand.nextInt(5) == 0)
				//{
					//event.getEntityLiving().entityDropItem(new ItemStack(BlockInit.OKONOTH_BLOCK), 0.0f);
				//}
			//}
	//	}
	//}
}
}
