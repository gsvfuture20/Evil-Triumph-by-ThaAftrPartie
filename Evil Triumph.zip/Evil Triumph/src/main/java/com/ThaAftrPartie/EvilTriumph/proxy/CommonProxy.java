package com.ThaAftrPartie.EvilTriumph.proxy;

import net.minecraft.item.Item;

public class CommonProxy {
	
	public void registerItemRednerer(Item item, int meta, String id)
	{
		
	}

	

}
