package com.ThaAftrPartie.EvilTriumph.tabs;

import java.io.File;

import net.minecraft.creativetab.CreativeTabs;

public class evilTriumph {

	public static final CreativeTabs EvilTriumphTab = null;
	public static File config;

}
