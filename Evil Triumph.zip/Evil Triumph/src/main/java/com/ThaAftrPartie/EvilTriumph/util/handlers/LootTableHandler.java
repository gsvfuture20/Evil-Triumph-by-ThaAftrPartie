package com.ThaAftrPartie.EvilTriumph.util.handlers;


import com.ThaAftrPartie.EvilTriumph.util.Reference;

import net.minecraft.util.ResourceLocation;
import net.minecraft.world.storage.loot.LootTableList;

public class LootTableHandler {
	
{
	LootTableList.register(new ResourceLocation(Reference.MOD_ID + ":loot_tables/"));
}


}
