package com.ThaAftrPartie.EvilTriumph.init;

	import com.ThaAftrPartie.EvilTriumph.objects.blocks.BlockBase;
	import java.util.ArrayList;
	import java.util.List;


import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

	public class BlockInit
	{
		public static final List<Block> BLOCKS = new ArrayList<Block>();
		
		//public static final Block TEST_GRASS_PATH = new BlockTestGrassPath("test_grass_path");
		//public static final Block SILVER_BLOCK = new BlockBase("silver_block", Material.IRON);
		public static final Block OKONOTH_BLOCK = new BlockBase("okonoth_block", Material.IRON);
		
	
	
	

}
